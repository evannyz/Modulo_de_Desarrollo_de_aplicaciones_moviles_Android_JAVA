package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.RowId;
import java.util.ArrayList;

public class ActividadBusquedaServicio extends AppCompatActivity {

    private EditText etbusser, etdirser; // Edit text que recibe la busqueda de servicio y la direccion
    private Spinner splist;              //lista que aparece según el servicio seleccionado y la comuna
    private ArrayList<String> listaProfesionales;   //lista de profesionales tipo string
    private ArrayList<Profesional> profesionalLista; // lista de objetos tipo profesional


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_busqueda_servicio);
        etbusser=findViewById(R.id.etingresoserv);
        etdirser=findViewById(R.id.etingresodir);
        splist=findViewById(R.id.splistacandidatos);


        consultarListaProfesional();


        ArrayAdapter<String> adapter= new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,listaProfesionales);
        splist.setAdapter(adapter);







    }

    public void consultarListaProfesional(){
        Admindb admin = new Admindb(this,"Profesionales",null,1);
        SQLiteDatabase base = admin.getWritableDatabase();

        Profesional p1=null;
        profesionalLista = new ArrayList<Profesional>();
        Cursor fila = base.rawQuery("select rowid, nombres, apepat, apemat from Profesionals ",null);

        while (fila.moveToNext()){
            p1= new Profesional();
            p1.setIdProfesional(fila.getInt(0));
            p1.setNombres(fila.getString(1));
            p1.setApepat(fila.getString(2));
            p1.setApemat(fila.getString(3));
            profesionalLista.add(p1);

        }

        consultarProfesional();


    }

    public void consultarProfesional(){
        listaProfesionales = new ArrayList<String>();
        for (int i =0;i<profesionalLista.size();i++){
            listaProfesionales.add(profesionalLista.get(i).getIdProfesional()+ " "+profesionalLista.get(i).getNombres()+"  "+profesionalLista.get(i).getApepat()+" - "
                    + profesionalLista.get(i).getApemat());
        }

    }




    public void busquedaProfesional(View v){

        String ingreso = etbusser.getText().toString();
        String direccion= etdirser.getText().toString();


        if (!ingreso.isEmpty() && !direccion.isEmpty()){


        }else{
            Toast.makeText(this,"Debe ingresar todos los campos",Toast.LENGTH_LONG).show();
        }

    }

    public void seleccionSpinner (View v){

        /*String selected =splist.getSelectedItem().toString();*/


        Intent caso = new Intent(this,contratar_servicio.class);

        caso.putExtra("datos1",splist.getSelectedItem().toString());
        caso.putExtra("dato2",splist.getSelectedItemPosition());


        startActivity(caso);


    }

    public void volverActividadMainInicio(View v){
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);

    }



}