package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ingresarServicio(View view) {
        Intent intent = new Intent(this, IngresarServicio.class);
       // intent.putStringArrayListExtra();
        startActivity(intent);

    }

    public void dirigeBusquedaServicio(View v){
        Intent dirige = new Intent(this, ActividadBusquedaServicio.class);
        startActivity(dirige);
    }
    public void contratarServicio(View v){
        Intent contratarServicio=new Intent(this,contratar_servicio.class);
        startActivity(contratarServicio);
    }
    public void registraProfesional(View v){
        Intent profesional = new Intent(this, MainProfesional.class);
        startActivity(profesional);
    }

    public void irUsuario (View v){
        Intent passUsuario=new Intent(this, RegistroUsuarios.class);
        startActivity(passUsuario);
    }
    public void IngresarProfesional(View v){
        Intent IngresarProfesional=new Intent(this,MainProfesional.class);
        startActivity(IngresarProfesional);
    }


}

