package com.example.appdecuentas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ActividadRegistrar extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spslmes;
    private EditText etregistro;
    private TextView tv1,tv2;
    private String[] select = {"Seleccione mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_registrar);
        spslmes=findViewById(R.id.spselectmes);
        etregistro=findViewById(R.id.etingresonumrg);
        tv1=findViewById(R.id.tvmostrard1rg);
        tv2=findViewById(R.id.tvmostrard2rg);

        ArrayAdapter<String> adapter= new ArrayAdapter<>(this, R.layout.spinner_item_evans,select);
        spslmes.setAdapter(adapter);
        spslmes.setOnItemSelectedListener(this);




    }

    public void botonAgua(View v){
        tv1.setText("Agua");
    }

    public void botonLuz(View v){
        tv1.setText("Electricidad");
    }

    public void botonGas(View v){
        tv1.setText("Gas");
    }

    public void botonTv(View v){
        tv1.setText("Television");
    }

    public void botonTelefono(View v){
        tv1.setText("Telefonia");
    }

    public void botonInternet(View v){
        tv1.setText("Internet");
    }







    public void ingresarRegistro(View v){

        String registro = etregistro.getText().toString();




        if(tv1.getText().equals("")||tv2.getText().equals("Seleccione mes")||registro.equals("")){
            Toast.makeText(getApplicationContext(),"Ingrese servicio, mes de registro y monto a registrar",Toast.LENGTH_LONG).show();

        }else{



            Admindb admin = new Admindb(getApplicationContext(),"Registro",null,1);
            SQLiteDatabase base = admin.getWritableDatabase();



            ContentValues c = new ContentValues();
            c.put("nombre",tv1.getText().toString());
            int idserbase= (int) base.insert("servicio",null,c);

            ContentValues d= new ContentValues();
            d.put("nombre",tv2.getText().toString());
            int idmes = (int) base.insert("meses",null,d);

            String precio = etregistro.getText().toString();
            int conv= Integer.parseInt(precio);

            ContentValues e = new ContentValues();
            e.put("precio",conv);
            e.put("id_mes",idmes);
            e.put("id_servicio",idserbase);
            base.insert("registroServicioMes",null,e);



            base.close();


            Intent volver = new Intent(this,MainActivity.class);
            startActivity(volver);
            Toast.makeText(getApplicationContext(),"Su registro fue creado exitosamente",Toast.LENGTH_LONG).show();

        }

    }


    public void volverMainRegistrar (View v){
        Intent volver = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(volver);

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
        String item = parent.getItemAtPosition(pos).toString();
        tv2.setText(item);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        tv2.setText("");

    }
}