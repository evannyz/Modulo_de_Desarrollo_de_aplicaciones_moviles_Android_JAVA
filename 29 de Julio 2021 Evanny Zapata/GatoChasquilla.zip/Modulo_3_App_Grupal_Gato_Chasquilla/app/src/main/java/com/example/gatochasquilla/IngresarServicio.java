package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;

public class IngresarServicio extends AppCompatActivity {

    private RadioGroup grupo;
    private Admindb admin;
    private SQLiteDatabase base;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar_servicio);

        admin = new Admindb(this, "Profesionaless", null, 1);
        base = admin.getWritableDatabase();

        ContentValues values = new ContentValues();

        base.delete("Categoria", "", null);

        ingresoCategorias(values);

        grupo = findViewById(R.id.radioGroup);

        Cursor cursor = base.rawQuery("select rowid, descripcion from Categoria", null);

        ArrayList<String> descripcion = new ArrayList<>();
        ArrayList<Integer> ids = new ArrayList<>();

        while (cursor.moveToNext()){

            ids.add(cursor.getInt(0));
            descripcion.add(cursor.getString(1));

        }
        for(int i = 0; i < grupo.getChildCount(); i++){
            RadioButton btn = (RadioButton)grupo.getChildAt(i);
            btn.setText(ids.get(i) + " - " + descripcion.get(i));
        }




    }

    public void ingresoCategorias(ContentValues values){

        values.put("descripcion", "Gasfiteria");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();

        values.put("descripcion", "Carpinteria");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();

        values.put("descripcion", "Albañileria");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();

        values.put("descripcion", "Electricidad");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();

        values.put("descripcion", "Auxiliares");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();

        values.put("descripcion", "Otra");
        values.put("estado", 1);

        base.insert("Categoria", null, values);

        values.clear();
    }

    public void ingresarServicio(View view){
        //TODO
    }
    public void volver(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}