package com.example.appdecuentas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void registrarGastos (View v) {
        Intent dirige1 = new Intent(this, ActividadRegistrar.class);
        startActivity(dirige1);
    }

    public void consultarGastos (View v){
        Intent dirige2 = new Intent(this,ActividadConsultar.class);
        startActivity(dirige2);
    }

    public void compararGastos (View v){
        Intent dirige2 = new Intent(this,ActividadComparar.class);
        startActivity(dirige2);
    }


}