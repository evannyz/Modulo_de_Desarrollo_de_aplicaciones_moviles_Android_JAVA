package com.example.gatochasquilla;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Admindb extends SQLiteOpenHelper {

    public Admindb(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table Usuarios(nombres varchar, apepat varchar, apemat varchar, run varchar, fecha_nac date, direccion varchar, telefono varchar, mail varchar)");
        //tipo 1= persona natural, 2= empresa -> esto define si en pantalla muestra apepat y apemat, nombres es tambien razonsocial
        db.execSQL("create table Profesionals( tipo int, nombres varchar, apepat varchar, apemat varchar, direccion varchar, telefono varchar, mail varchar)");
        // estado 1=activo, 2=desactivado
        db.execSQL("create table Servicios( descripcion varchar, estado int, categoria_id int)");
        //tabla intermedia entre servicios y profesionales, por ser una relacion Muchos:Muchos
        db.execSQL("create table Profesional_servicios( profesional_id int, servicio_id int)");
        //registro de contratos de servicios entre CLientes y Profesionales
        //estado_contrato
        // 0=contrato anulado
        // 1=contrato abierto,
        // 2=contrato en ejecucion,
        // 3=contrato con observaciones (problemas de ejecucion)
        // 4=contrato pendiente pago,
        // 5=contrato finalizado
        db.execSQL("create table Contratos( cliente_id int, profesional_id, servicio_id int, estado_contrato int)");
        //Categoria Servicio
        db.execSQL("create table Categoria( descripcion varchar, estado int)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
