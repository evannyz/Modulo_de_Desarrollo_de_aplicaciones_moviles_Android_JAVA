package com.example.appdecuentas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Admindb extends SQLiteOpenHelper {
    public Admindb(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        //Base de dato con sqlite, ingreso de tablas meses, servicio y
        db.execSQL("create table meses(idmes integer not null primary key autoincrement, nombre varchar)");

        db.execSQL("create table servicio(idservicio integer not null primary key autoincrement, nombre varchar)");

        db.execSQL("create table registroServicioMes(idreg  integer primary key autoincrement, id_mes INTEGER not null,id_servicio INTEGER not null , precio int, foreign key (id_mes)  references meses(idmes)  , foreign key(id_servicio) references servicio(idservicio))");



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
