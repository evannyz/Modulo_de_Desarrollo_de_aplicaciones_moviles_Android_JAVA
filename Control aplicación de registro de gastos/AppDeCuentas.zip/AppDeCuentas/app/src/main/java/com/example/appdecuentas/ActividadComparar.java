package com.example.appdecuentas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ActividadComparar extends AppCompatActivity {


    private String glovar1 = "Seleccione servicio", glovar2,glovar3;
    private Spinner spservicio, spmes1, spmes2;
    private TextView tvservicio, tvmesuno, tvmesdos;
    private ListView listuno, listdos;

    private String[] select1 = {"Agua","Electricidad","Gas","Television","Telefonia","Internet"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_comparar);

        spservicio=findViewById(R.id.spserviciocom);


        tvservicio=findViewById(R.id.tvservicom);
        tvmesuno=findViewById(R.id.tvunocom);
        tvmesdos=findViewById(R.id.tvdoscom);
        listuno=findViewById(R.id.lvmesunocom);
        listdos=findViewById(R.id.lvmesdoscom);



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.spinner_item_evans,select1);
        spservicio.setAdapter(adapter);

        spservicio.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String opcion = parent.getItemAtPosition(pos).toString();
                tvservicio.setText(opcion);


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tvservicio.setText("");
            }
        });

        comparaServicio();




    }

    public void comparaServicio(){

        String dato1= tvservicio.getText().toString();


            Admindb admin = new Admindb(getApplicationContext(), "Registro", null, 1);
            SQLiteDatabase base = admin.getWritableDatabase();


            Cursor cursor2 = base.rawQuery("select m.nombre, rsm.precio, s.nombre " +
                    "from registroServicioMes as rsm " +
                    "inner join meses as m " +
                    "on rsm.id_mes = m.idmes " +
                    "inner join servicio as s " +
                    "on rsm.id_servicio = s.idservicio", null);






            ArrayList<String> comparacion = new ArrayList<>();


            while (cursor2.moveToNext()) {

                if(dato1.equals(cursor2.getString(2))) {
                    comparacion.add(cursor2.getString(0) + " - " + cursor2.getString(1));
                }



            }




            ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, R.layout.listview_item_evans, comparacion);
            listuno.setAdapter(adapter2);




        }




    public void comparacionBoton(View v){


    }

    public void volverMainComparar (View v){
        Intent volver = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(volver);

    }


}