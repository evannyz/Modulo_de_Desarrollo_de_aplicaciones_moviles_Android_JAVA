package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class RegistroUsuarios extends AppCompatActivity {
    private EditText nu,apu,amu,ru,fnu,du,tu,mu;
    private Switch robot;
    private Button butUs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuarios);

        nu=findViewById(R.id.nombreUsuario);
        apu=findViewById(R.id.apellidopUsuario);
        amu=findViewById(R.id.apellidomUsuario);
        ru=findViewById(R.id.rutUsuario);
        fnu=findViewById(R.id.fnacUsuario);
        du=findViewById(R.id.direccionUsuario);
        tu=findViewById(R.id.telefonoUsuario);
        mu=findViewById(R.id.emailUsuario);
        robot=findViewById(R.id.switchUsuario);
        butUs=findViewById(R.id.buttonUsuario);

    }

    public void mostrarCalendario (View v){
        DatePickerDialog date = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                fnu.setText(dayOfMonth+"/"+month+1+"/"+year);
            }
        },2021,0,1);
        date.show();
    }

    public void volver(View view){
        Intent volver=new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void registrarUsuario (View v){
        if (robot.isChecked()){
            Admindb admin = new Admindb(this, "Usuario", null, 1);
            SQLiteDatabase base=admin.getWritableDatabase();

            String nombre=nu.getText().toString();
            String apellp=nu.getText().toString();
            String apellm=nu.getText().toString();
            String rut=nu.getText().toString();
            String fnac=nu.getText().toString();
            String dir=nu.getText().toString();
            String tel=nu.getText().toString();
            String email=nu.getText().toString();

            if (!nombre.isEmpty() && !apellp.isEmpty() && !apellm.isEmpty() && !rut.isEmpty()
            && !fnac.isEmpty() && !dir.isEmpty() && !tel.isEmpty() && !email.isEmpty()){

                ContentValues crear = new ContentValues();
                crear.put("Nombre", nombre);
                crear.put("Apellido P", apellp);
                crear.put("Apellido M", apellm);
                crear.put("Rut ", rut);
                crear.put("F Nacimiento", fnac);
                crear.put("Direccion", dir);
                crear.put("Telefono", tel);
                crear.put("Correo", email);

                base.insert("Usuarios", null, crear);
                base.close();

                nu.setText("");
                apu.setText("");
                amu.setText("");
                ru.setText("");
                fnu.setText("");
                du.setText("");
                tu.setText("");
                mu.setText("");
                robot.setText("");
                butUs.setText("");
                Toast.makeText(this, "Usuario creado exitosamente", Toast.LENGTH_SHORT).show();
                aHome();
            } else {
                Toast.makeText(this, "Debe llenar todos los campos", Toast.LENGTH_LONG).show();
            }

        } else {
            Toast.makeText(this, "Debe confirmar que no es un robot", Toast.LENGTH_LONG).show();
        }


    }

    public void aHome(){
        Intent home=new Intent(this, Home.class);
        startActivity(home);
    }


}