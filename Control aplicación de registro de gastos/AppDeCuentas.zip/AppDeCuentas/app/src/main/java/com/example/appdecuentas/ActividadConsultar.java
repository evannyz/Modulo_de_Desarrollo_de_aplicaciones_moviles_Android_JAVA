package com.example.appdecuentas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ActividadConsultar extends AppCompatActivity {


    private TextView tvvistaser,tvvistames;
    private Spinner spmesca,spserca;
    private ListView lvdatosca;

    private String[] select1 = {"Seleccione servicio","Agua","Electricidad","Gas","Television","Telefonia","Internet"};
    private String[] select2 = {"Seleccione mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_consultar);
        spserca=findViewById(R.id.spconsultarser);
        spmesca=findViewById(R.id.spconsultames);
        tvvistaser=findViewById(R.id.tvvistauno);
        tvvistames=findViewById(R.id.tvvistados);
        lvdatosca=findViewById(R.id.lvconsultaca);

        ArrayAdapter adapter1=new ArrayAdapter(getApplicationContext(), R.layout.spinner_item_evans,select1);
        spserca.setAdapter(adapter1);

        spserca.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                String item= parent.getItemAtPosition(pos).toString();
                tvvistaser.setText(item);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tvvistaser.setText("");

            }
        });



        ArrayAdapter adapter2=new ArrayAdapter(this, R.layout.spinner_item_evans,select2);
        spmesca.setAdapter(adapter2);
        spmesca.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                String item2 = parent.getItemAtPosition(pos).toString();
                tvvistames.setText(item2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tvvistames.setText("");

            }
        });




    }

    public void consultarServicioMes(View view) {

        String datoser = tvvistaser.getText().toString();
        String datomes = tvvistames.getText().toString();

        if(!datoser.equals("Seleccione servicio") && !datomes.equals("Seleccione mes")){

            /* pensado en usar where CharSequence ser = "%" + datoser + "%";
            CharSequence mes = "%" + datomes + "%" */;


            Admindb admin = new Admindb(getApplicationContext(), "Registro", null, 1);
            SQLiteDatabase base = admin.getWritableDatabase();


            Cursor cursor = base.rawQuery("select m.nombre, rsm.precio, s.nombre " +
                    "from registroServicioMes as rsm " +
                    "inner join meses as m " +
                    "on rsm.id_mes = m.idmes " +
                    "inner join servicio as s " +
                    "on rsm.id_servicio = s.idservicio", null);



            ArrayList<String> lista = new ArrayList<>();

            while (cursor.moveToNext()) {

                if(datoser.equals(cursor.getString(2)) && datomes.equals(cursor.getString(0)))
                lista.add(cursor.getString(2) + " - " + cursor.getString(0) + " - " + cursor.getString(1));


            }

            if(lista == null|| lista.size()==0){

                Toast.makeText(this,"No existen registros de gastos del mes y el servicio ",Toast.LENGTH_LONG).show();
            }else {

                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.listview_item_evans, lista);
                lvdatosca.setAdapter(adapter);
            }

            base.close();


        }else{
            Toast.makeText(this,"Debe seleccionar los campos de mes y servicio",Toast.LENGTH_LONG).show();
        }
    }

    public void volverMainConsultar (View v){
        Intent volver = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(volver);

    }


}